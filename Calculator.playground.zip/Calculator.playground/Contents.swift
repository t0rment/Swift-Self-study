import UIKit


/*1. Create a console calculator (without copying code).
 2. Write a function that determines whether a number is prime.
 3. Write a function that reverses a string.
 4. Implement FizzBuzz.
 5. Find the second-largest number in an array.
 6. Count the frequency of each character in a string*/

//1//
func calculator(num1: Int, num2: Int, operation: String) -> Int? {

    switch operation {

    case "+":
        return num1 + num2

    case "-":
        return num1 - num2

    case "*":
        return num1 * num2

    case "/":
        if num2 == 0 {
            print("Cannot divide by zero.")
            return nil
        }
        return num1 / num2

    default:
        print("Unknown operator")
        return nil
    }
}

print(calculator(num1: 10, num2: 5, operation: "+") ?? 0)
