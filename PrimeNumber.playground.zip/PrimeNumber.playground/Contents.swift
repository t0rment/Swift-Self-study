import UIKit

//2//
func isPrime(number: Int) -> Bool {

    if number <= 1 {
        return false
    }
    for i in 2..<number {
        if number % i == 0 {
            return false
        }
    }
    return true
}

print(isPrime(number: 13))
print(isPrime(number: 15))
