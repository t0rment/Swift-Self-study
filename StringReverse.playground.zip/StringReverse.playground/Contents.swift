import UIKit

//3//
func reverseString(text: String) -> String {
    return String(text.reversed())
}

print(reverseString(text: "Hello"))
